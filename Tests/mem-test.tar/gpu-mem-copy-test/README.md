gpu-mem-copy-test
=================